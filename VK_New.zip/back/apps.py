from django.apps import AppConfig


class BackConfig(AppConfig):
    name = 'back'
